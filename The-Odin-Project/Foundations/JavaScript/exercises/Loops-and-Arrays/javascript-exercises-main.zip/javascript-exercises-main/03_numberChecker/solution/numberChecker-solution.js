function numberChecker(number) {
  if (number >= 10) {
    return true;
  } else {
    return false;
  }
}

module.exports = numberChecker;
