const a = 1 - 1
const b = 1 + 8
const c = 22 * 3
const d = 5 % 4
const e = b - 17
const f = a + b + c + d + e

module.exports = {a, b, c, d, e, f}
