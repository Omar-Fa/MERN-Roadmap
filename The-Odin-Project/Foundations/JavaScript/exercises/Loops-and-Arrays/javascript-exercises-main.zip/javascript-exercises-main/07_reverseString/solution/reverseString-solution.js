const reverseString = function (string) {
  return string.split("").reverse().join("");
};

module.exports = reverseString;
